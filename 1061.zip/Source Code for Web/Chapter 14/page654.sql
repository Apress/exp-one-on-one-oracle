 alter tablespace p1 offline;


 alter tablespace p2 offline;


 alter tablespace p3 offline;


select empno,job,loc from emp where empno = 7782;

select empno,job,loc from emp where job = 'CLERK';

select count(*) from emp where job = 'CLERK';