drop table lob_demo
/

create table lob_demo
( owner     varchar2(255),
  timestamp date,
  filename  varchar2(255),
  text      clob
)
/
