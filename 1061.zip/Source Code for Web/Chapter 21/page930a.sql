@connect smith/smith

column namespace format a10
column attribute format a10
column value     format a10
select * from session_context;

