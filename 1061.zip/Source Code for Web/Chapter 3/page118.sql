set echo on;

drop table t1;
drop table t2;

create table t1 ( x int );

create table t2 ( x int );

insert into t1 values ( 1 );

insert into t2 values ( 1 );

select username,
       v$lock.sid,
           id1, id2,
       lmode,
           request, block, v$lock.type
from v$lock, v$session
where v$lock.sid = v$session.sid
  and v$session.username = USER
/

select object_name, object_id from user_objects;

