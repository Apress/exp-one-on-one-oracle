select * from people order by home_address;

select * from people where home_address > work_address;

select * from people where home_address = work_address;
