select 90101, dump(reverse(90101),16) from dual
union all
select 90102, dump(reverse(90102),16) from dual
union all
select 90103, dump(reverse(90103),16) from dual
/
